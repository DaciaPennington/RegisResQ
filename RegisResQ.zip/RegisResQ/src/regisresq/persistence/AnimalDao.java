package regisresq.persistence;

import java.util.List;
import regisresq.application.*; // Needed for the domain classes
import java.sql.Connection; // Needed to establish a DB connection
import java.sql.DriverManager; // Needed to connect to the DB server
import java.sql.ResultSet; // Needed to store the result of a SQL query
import java.sql.Statement; // Needed to create a SQL query
import java.sql.SQLException; // All DB ops must be in try-catch blocks
import java.util.*; // Needed for the ArrayList ADT
import regisresq.application.Animal;


/**
 *
 * @author Dacia Pennington
 */



public class AnimalDao implements Dao<Animal>{
    
    private List<Animal> animals;
    private Connection connection = null;
    private Statement statement = null;
    private ResultSet resultSet = null;
    
    public AnimalDao(){
    
        animals = new ArrayList<Animal>();    
        
        try{
            Class.forName("com.mysql.cj.jdbc:Driver");
            connection = DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/animals", "cs444",
                    "p@sswordCS444");
        }
        catch(ClassNotFoundException | SQLException e){
            System.out.println(e); //may need better error message
        }
        
        
    }

    @Override
    public List<Animal> getAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Boolean add(Animal item) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Boolean update(Animal item) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Boolean delete(Animal item) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }




}
