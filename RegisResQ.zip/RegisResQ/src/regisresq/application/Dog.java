/*
 * Dacia Pennington
 * CS 444
 * RegisResQ Part 1: SRS 10, 14, & 15
 *
 */
package regisresq.application;

import regisresq.application.Animal;

/**
 * A class representing an animal species: dog
 * 
 * @author Dacia Pennington
 * @version 1.0
 */
public class Dog extends Animal{

    /**
     * Default constructor for class dog. All fields set to animal default 
     * except species which is set to "dog"
     */
    public Dog() {
        
        super();
        super.species = "dog";
    }

    /**
     * Constructor for class dog that allows creating a dog Object with a 
     * specified breed, name, sterilization status, and arrival date. 
     * Except species which is set to "dog"
     * 
     * @param breed - breed of dog (String)
     * @param name - name of dog (String)
     * @param sterilized - is the animal spayed/neutered (boolean)
     * @param dateArrived - arrival date of dog (String)
     */
    public Dog(String breed, String name, boolean sterilized,
        String dateArrived) {
        
        super(breed, name, sterilized, dateArrived);
        super.species = "dog";
    }


}


