/*
 * Dacia Pennington
 * CS 444
 * RegisResQ Part 1: SRS 10, 14, & 15
 *
 */
package regisresq.application;

import regisresq.application.Animal;

/**
 * A class representing an animal species: cat
 * 
 * @author Dacia Pennington
 * @version 1.0
 */
public class Cat extends Animal{

    /**
     * Default constructor for class cat. All fields set to animal default 
     * except species which is set to "cat"
     */
    public Cat() {
        
        super();
        super.species = "cat";
    }

    /**
     * Constructor for class cat that allows creating a cat Object with a 
     * specified breed, name, sterilization status, and arrival date.
     * Except species which is set to "cat"
     * 
     * @param breed - breed of cat (String)
     * @param name - name of cat (String)
     * @param sterilized - is the animal spayed/neutered (boolean)
     * @param dateArrived - arrival date of cat (String)
     */
    public Cat(String breed, String name, boolean sterilized,
        String dateArrived) {
        
        super(breed, name, sterilized, dateArrived);
        super.species = "cat";
       
    }

}
