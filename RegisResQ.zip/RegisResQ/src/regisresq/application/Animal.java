/*
 * Dacia Pennington
 * CS 444
 * RegisResQ Part 1: SRS 10, 14, & 15
 *
 */
package regisresq.application;

import java.io.*;


/**
 * An abstract class that defines the top-level hierarchy of animals for a 
 * rescue/adoption platform called RsgisResQ
 * 
 * @author Dacia Pennington
 * @version 1.0
 */
public abstract class Animal {

    protected String species;
    protected String breed;
    protected String name;
    protected boolean sterilized;
    protected String dateArrived;

    /**
     * Default constructor for Animal class initializing all fields excluding species to
     * null for String and false for boolean.
     */
    public Animal() {
        breed = null;
        name = null;
        sterilized = false;
        dateArrived = null;
    }

    /**
     * Constructor for Animal class that allows external setting of all fields 
     * excluding species.
     * 
     * @param breed - breed of animal
     * @param name - name of animal
     * @param sterilized - is the animal spayed/neutered
     * @param dateArrived - an animal's date of arrival at the rescue
     */
    public Animal(String breed, String name, boolean sterilized, String dateArrived) {
        this.breed = breed;
        this.name = name;
        this.sterilized = sterilized;
        this.dateArrived = dateArrived;
    }

    /**
     * Allows retrieving of the Animal species for the specified animal.
     * 
     * @return species - species of animal (String)
     */
    public String getSpecies() {
        return species;
    }

    /**
     * Allows retrieving of the Animal breed for the specified animal.
     * 
     * @return breed - breed of animal (String)
     */
    public String getBreed() {
        return breed;
    }

    /**
     * Allows retrieving of the Animal name for the specified animal.
     *
     * @return name - name of animal (String)
     */
    public String getName() {
        return name;
    }

    /**
     * Allows retrieving of the sterilization status for the specified animal.
     * 
     * @return sterilized - status of animal sterilization (boolean)
     */
    public boolean isSterilized() {
        return sterilized;
    }

    /**
     * Allows retrieving of the date of arrival for the specified animal.
     * 
     * @return dateArrived - the admit date of a specific animal.
     */
    public String getDateArrived() {
        return dateArrived;
    }

    /**
     * Allows setting the breed of the animal. 
     * 
     * @param breed - breed of animal (String)
     */
    public void setBreed(String breed){
        this.breed= breed;
    }

    /**
     * Allows setting the name of the animal.
     * 
     * @param name - name of animal (String)
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Allows setting the sterilization status of the animal.
     * 
     * @param sterilized - true if animal has been spayed or neutered and false
     * otherwise.
     */
    public void setSterilized(boolean sterilized) {
        this.sterilized = sterilized;
    }

    /**
     * Allows setting the arrival date of the animal.
     * 
     * @param dateArrived - String format YYYY-MM-DD
     */
    public void setDateArrived(String dateArrived) {
        this.dateArrived = dateArrived;
    }

    /**
     * To string display of animal information.
     * 
     * @return String
     */
    @Override
    public String toString() {
        return "Animal{" + "species=" + species + ", breed=" + breed + ", name=" + name + ", sterilized=" + sterilized + ", dateArrived=" + dateArrived + '}';
    }

    /**
     * Verifies the validity of all class attributes.
     * 
     * @return valid - true if all animal parameters have been set correctly and
     * false otherwise
     * @throws NullPointerException if String fields are null
     */
    public boolean validate(){
        
        String dateSplit[]; 
        String month;
        String day;
        String year;
        
        try{
            if(breed.matches(null) || breed.isEmpty())
                return false;
        
            if(name.matches(null) || name.isEmpty())
                return false;
        
            if(dateArrived.matches(null) || dateArrived.isEmpty())
                return false;
        }
        catch(NullPointerException e){
            return false;
        }
       
        if(dateArrived.matches("\\d{4}-\\d{2}-\\d{2}")){
            dateSplit = dateArrived.split("-");
            year = dateSplit[0];
            month = dateSplit[1];
            day = dateSplit[2];
            
            switch(month){
                case "01":
                case "03":
                case "05":
                case "07":
                case "08":
                case "10":
                case "12":
                    return(Integer.parseInt(day) <= 31);
                case "02":
                     if((Integer.parseInt(year) % 4 == 0 &&
                         Integer.parseInt(year) % 100 != 0) || 
                         (Integer.parseInt(year) % 400 == 0))
                         return (Integer.parseInt(day) <= 29);
                     else
                         return (Integer.parseInt(day) <= 28);
                case "04":
                case "06":
                case "09":
                case "11":
                    return(Integer.parseInt(day) <= 30);
                default:
                    return false;
            }    
        }
        else
            return false;
    }
}