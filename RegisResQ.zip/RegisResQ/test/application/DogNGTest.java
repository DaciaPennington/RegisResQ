/*
 * Dacia Pennington
 * CS 444
 * RegisResQ Part 1: SRS 10, 14, & 15
 *
 */
package application;

import regisresq.application.Dog;
import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * A class for testing the representation of an animal species: dog
 * 
 * @author Dacia Pennington
 * @version 1.0
 */
public class DogNGTest {
    
    public DogNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    /**
     * Test which asserts False the result of the Animal class validation test 
     * until all attributed are properly entered for the species dog.
     */
    @Test
    public void testValidate(){
        Dog testDog = new Dog();
        
        boolean result = testDog.validate();
        assertFalse(result);
        
        testDog.setBreed("");
        result = testDog.validate();
        assertFalse(result);
        
        testDog.setBreed(null);
        result = testDog.validate();
        assertFalse(result);
        
        testDog.setBreed("Husky");
        result = testDog.validate();
        assertFalse(result);
        
        testDog.setName("");
        result = testDog.validate();
        assertFalse(result);
        
        testDog.setName(null);
        result = testDog.validate();
        assertFalse(result);
        
        testDog.setName("Joey");
        result = testDog.validate();
        assertFalse(result);
        
        /*
        Series of invalid date settings
        */
        
        testDog.setDateArrived(null);
        result = testDog.validate();
        assertFalse(result);
        
        testDog.setDateArrived("2020-14-14"); //invalid month
        result = testDog.validate();
        assertFalse(result);
        
        testDog.setDateArrived("2020-12-40"); //invalid day overall
        result = testDog.validate();
        assertFalse(result);
        
        testDog.setDateArrived("2020-04-31"); //invalid day for month
        result = testDog.validate();
        assertFalse(result);
        
        testDog.setDateArrived("2021-02-29"); //leap year day on non-leap year
        result = testDog.validate();
        assertFalse(result);
        
        testDog.setDateArrived("2021/7/12"); //bad date format
        result = testDog.validate();
        assertFalse(result);
        
        /*
        Valid date setting
        */
        testDog.setDateArrived("2020-02-29"); // valid leap year
        result = testDog.validate();
        assertTrue(result);       
    }
    
}
