/*
 * Dacia Pennington
 * CS 444
 * RegisResQ Part 1: SRS 10, 14, & 15
 *
 */
package application;

import regisresq.application.Cat;
import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * A class for testing the representation of an animal species: cat
 * 
 * @author Dacia Pennington
 * @version 1.0
 */
public class CatNGTest {
    
    public CatNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    /**
     * Test which asserts False the result of the Animal class validation test 
     * until all attributed are properly entered for the species cat.
     */
    @Test
    public void testValidate() {
        Cat testCat = new Cat();
        
        boolean result = testCat.validate();
        assertFalse(result);
        
        testCat.setBreed("");
        result = testCat.validate();
        assertFalse(result);
        
        testCat.setBreed(null);
        result = testCat.validate();
        assertFalse(result);
        
        testCat.setBreed("Maine Coon");
        result = testCat.validate();
        assertFalse(result);
        
        testCat.setName("");
        result = testCat.validate();
        assertFalse(result);
        
        testCat.setName(null);
        result = testCat.validate();
        assertFalse(result);
        
        testCat.setName("Lilly");
        result = testCat.validate();
        assertFalse(result);
        
        /*
        Series of invalid date settings
        */
        
        testCat.setDateArrived(null);
        result = testCat.validate();
        assertFalse(result);
        
        testCat.setDateArrived("2020-14-14"); //invalid month
        result = testCat.validate();
        assertFalse(result);
        
        testCat.setDateArrived("2020-12-40"); //invalid day for any month
        result = testCat.validate();
        assertFalse(result);
        
        testCat.setDateArrived("2020-04-31"); //invalid day for month
        result = testCat.validate();
        assertFalse(result);
        
        testCat.setDateArrived("2021-02-29"); //leap year day on non-leap year
        result = testCat.validate();
        assertFalse(result);
        
        testCat.setDateArrived("2021/7/12"); //bad date format
        result = testCat.validate();
        assertFalse(result);
        
        /*
        Valid date setting
        */
        testCat.setDateArrived("2020-02-28");
        result = testCat.validate();
        assertTrue(result);
    }
    
}
